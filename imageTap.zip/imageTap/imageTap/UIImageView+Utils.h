#import <UIKit/UIKit.h>

@interface UIImageView (Utils)

@property(nonatomic, retain) UIImageView *fullimageview;
@property(nonatomic, retain)UIImageView *temptumb;
@property(nonatomic, retain)UIView *viewbg;
@property(nonatomic, retain)UIView *view;

// METHOD FOR INITILIZE
-(void)methodPhotoViewerWithSuperView:(UIView *)view;

@end
