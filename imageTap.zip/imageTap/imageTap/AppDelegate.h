//
//  AppDelegate.h
//  imageTap
//
//  Created by OWNER on 01/09/17.
//  Copyright © 2017 OWNER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

